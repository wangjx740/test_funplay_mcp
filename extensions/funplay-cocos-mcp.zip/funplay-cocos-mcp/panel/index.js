'use strict';

const { createPanel } = require('./shared');

module.exports = createPanel('dashboard');
