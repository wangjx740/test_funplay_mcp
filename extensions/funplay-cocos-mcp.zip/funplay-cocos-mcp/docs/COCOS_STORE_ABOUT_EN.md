# Funplay MCP for Cocos

The Most Advanced MCP Server for Cocos Creator Editor with `execute_javascript`, prompts/resources, screenshots, asset dependency validation, tool profiles, one-click client configuration, version-aware global installation, and editor automation.

Connect AI coding assistants such as Claude Code, Cursor, Codex, VS Code Copilot, Trae, Kiro, Qoder, Kimi Code, OpenCode, and CodeBuddy IDE directly to your running Cocos Creator project, with real editor context for scene inspection, asset analysis, log debugging, and common development workflows.
